-- Run this entire file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.weddings (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  groom_name text not null,
  bride_name text not null,
  event_title text default 'The Wedding of',
  event_date timestamptz not null,
  event_time text,
  venue_name text,
  venue_address text,
  maps_url text,
  welcome_text text,
  story_text text,
  music_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.guests (
  id uuid primary key default gen_random_uuid(),
  wedding_id uuid not null references public.weddings(id) on delete cascade,
  full_name text not null,
  token text unique not null default encode(gen_random_bytes(18),'hex'),
  household_size integer not null default 2 check (household_size between 1 and 20),
  created_at timestamptz not null default now()
);

create table if not exists public.rsvps (
  id uuid primary key default gen_random_uuid(),
  wedding_id uuid not null references public.weddings(id) on delete cascade,
  guest_id uuid references public.guests(id) on delete set null,
  guest_name text not null,
  response text not null check (response in ('attending','declined')),
  guest_count integer not null default 0 check (guest_count between 0 and 20),
  created_at timestamptz not null default now(),
  unique (wedding_id, guest_id)
);

alter table public.weddings enable row level security;
alter table public.guests enable row level security;
alter table public.rsvps enable row level security;

-- Public visitors may read published invitation details.
create policy "Public can read wedding invitations" on public.weddings
for select to anon, authenticated using (true);

-- Guest token lookups are performed by the invitation route.
-- This starter policy allows token lookup through the anon client.
-- For production, move token validation to a server route to avoid exposing guest records.
create policy "Public can read guests for invitation" on public.guests
for select to anon, authenticated using (true);

-- RSVP submissions from invitation pages.
create policy "Public can submit RSVP" on public.rsvps
for insert to anon, authenticated with check (true);
create policy "Public can update RSVP" on public.rsvps
for update to anon, authenticated using (true) with check (true);

-- Only authenticated admins can manage wedding and guest records.
create policy "Admins manage weddings" on public.weddings
for all to authenticated using (true) with check (true);
create policy "Admins manage guests" on public.guests
for all to authenticated using (true) with check (true);
create policy "Admins read RSVPs" on public.rsvps
for select to authenticated using (true);

-- Demo wedding: change names/date/venue before publishing.
insert into public.weddings
(slug,groom_name,bride_name,event_title,event_date,event_time,venue_name,venue_address,welcome_text,story_text)
values
('kasun-nethmi','Kasun','Nethmi','The Wedding of','2027-02-14 10:00:00+05:30','10.00 AM','Your Wedding Venue','Colombo, Sri Lanka','With the blessings of our families, we invite you to join us as we begin our forever.','Two hearts, one journey, and a lifetime of memories.')
on conflict (slug) do nothing;

-- Example guest:
-- insert into public.guests (wedding_id, full_name, household_size)
-- select id, 'Amal Perera', 2 from public.weddings where slug='kasun-nethmi';
