export type Wedding = {
  id: string; slug: string; groom_name: string; bride_name: string;
  event_title: string; event_date: string; event_time: string | null;
  venue_name: string | null; venue_address: string | null; maps_url: string | null;
  welcome_text: string | null; story_text: string | null; music_url: string | null;
};
export type Guest = { id: string; wedding_id: string; full_name: string; token: string; household_size: number; };
