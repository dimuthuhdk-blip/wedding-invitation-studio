import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export function getSupabase() {
  if (!url || !anonKey) throw new Error("Supabase environment variables are missing. Copy .env.example to .env.local and add your project credentials.");
  return createClient(url, anonKey);
}
