"use client";
import { useRef, useState } from "react";
import { Music2, Pause, Play } from "lucide-react";
export default function MusicPlayer({ src }: { src?: string | null }) {
  const audio = useRef<HTMLAudioElement>(null);
  const [playing,setPlaying] = useState(false);
  if (!src) return <p className="text-xs text-stone-500">Wedding music will be added soon.</p>;
  async function toggle() {
    if (!audio.current) return;
    if (playing) { audio.current.pause(); setPlaying(false); }
    else { try { await audio.current.play(); setPlaying(true); } catch { setPlaying(false); } }
  }
  return <div className="flex justify-center items-center gap-3"><audio ref={audio} src={src} loop onPause={()=>setPlaying(false)} onPlay={()=>setPlaying(true)} /><button onClick={toggle} aria-label={playing ? "Pause music" : "Play music"} className="rounded-full border border-gold p-3 text-wine">{playing ? <Pause size={18}/> : <Play size={18}/>}</button><span className="text-xs tracking-widest uppercase text-stone-500 flex gap-2 items-center"><Music2 size={14}/> {playing ? "Music playing" : "Play wedding music"}</span></div>;
}
