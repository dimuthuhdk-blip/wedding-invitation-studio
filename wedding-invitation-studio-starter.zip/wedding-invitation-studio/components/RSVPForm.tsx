"use client";
import { FormEvent, useState } from "react";
import { getSupabase } from "@/lib/supabase";
export default function RSVPForm({ weddingId, guestId, maxGuests=2 }: { weddingId:string; guestId?:string; maxGuests?:number }) {
  const [name,setName] = useState("");
  const [status,setStatus] = useState("attending");
  const [count,setCount] = useState("1");
  const [message,setMessage] = useState("");
  const [busy,setBusy] = useState(false);
  async function submit(e:FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      const db = getSupabase();
      const { error } = await db.from("rsvps").upsert({
        wedding_id:weddingId, guest_id:guestId ?? null, guest_name:name,
        response:status, guest_count:status==="attending" ? Number(count) : 0
      }, { onConflict:"wedding_id,guest_id" });
      if (error) throw error;
      setMessage("Thank you! Your response has been received.");
    } catch (err) { setMessage(err instanceof Error ? err.message : "Unable to submit. Please try again."); }
    finally { setBusy(false); }
  }
  return <form onSubmit={submit} className="invite-paper rounded-2xl p-6 text-left max-w-xl mx-auto space-y-4">
    <h3 className="font-display text-2xl text-wine text-center">Kindly respond</h3>
    <label className="block text-sm">Your name<input required value={name} onChange={e=>setName(e.target.value)} className="mt-1 w-full rounded-lg border border-stone-300 bg-white p-3"/></label>
    <label className="block text-sm">Your response<select value={status} onChange={e=>setStatus(e.target.value)} className="mt-1 w-full rounded-lg border border-stone-300 bg-white p-3"><option value="attending">Joyfully accepts</option><option value="declined">Regretfully declines</option></select></label>
    {status==="attending" && <label className="block text-sm">Number attending<select value={count} onChange={e=>setCount(e.target.value)} className="mt-1 w-full rounded-lg border border-stone-300 bg-white p-3">{Array.from({length:Math.max(1,maxGuests)},(_,i)=><option key={i+1} value={i+1}>{i+1}</option>)}</select></label>}
    <button disabled={busy} className="w-full rounded-full bg-wine text-white py-3 disabled:opacity-50">{busy ? "Sending…" : "Send RSVP"}</button>
    {message && <p role="status" className="text-center text-sm text-wine">{message}</p>}
  </form>;
}
