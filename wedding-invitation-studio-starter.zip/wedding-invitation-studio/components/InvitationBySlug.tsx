"use client";
import { useState } from "react";
import Envelope from "@/components/Envelope";
import Countdown from "@/components/Countdown";
import MusicPlayer from "@/components/MusicPlayer";
import RSVPForm from "@/components/RSVPForm";
import { MapPin } from "lucide-react";
import type { Wedding } from "@/lib/types";
export default function InvitationBySlug({ wedding, guest }: { wedding:Wedding; guest:{id:string;full_name:string;household_size:number}|null }) {
  const [opened,setOpened]=useState(false);
  if(!opened) return <Envelope onOpen={()=>setOpened(true)} guestName={guest?.full_name}/>;
  return <main className="overflow-hidden">
    <header className="min-h-[85vh] story-scene flex flex-col items-center justify-center text-center px-5">
      <p className="uppercase tracking-[.3em] text-xs text-gold mb-6">Together with our families</p>
      <p className="font-display text-2xl text-wine">{wedding.event_title || "The Wedding of"}</p>
      <h1 className="font-display text-5xl md:text-7xl text-wine my-5">{wedding.groom_name}<span className="text-gold italic"> & </span>{wedding.bride_name}</h1>
      <div className="gold-rule w-40 my-5"/>
      <p className="uppercase tracking-widest text-sm">{new Date(wedding.event_date).toLocaleDateString("en-LK",{day:"numeric",month:"long",year:"numeric"})}</p>
      {guest&&<p className="mt-8 text-wine">Dear {guest.full_name}, we would be delighted by your presence.</p>}
    </header>
    <section className="py-24 px-6 text-center max-w-3xl mx-auto"><p className="font-display text-3xl text-wine leading-relaxed">{wedding.welcome_text || "With the blessings of our families, we invite you to celebrate our special day."}</p><p className="text-stone-500 mt-6">{wedding.story_text}</p></section>
    <section className="story-scene py-24 px-5 text-center"><div className="text-7xl mb-6">🚙</div><h2 className="font-display text-4xl text-wine">Our journey begins</h2><p className="text-stone-600 mt-4">A new chapter, together.</p></section>
    <section className="py-24 px-5 text-center"><h2 className="font-display text-4xl text-wine mb-8">Save the date</h2><Countdown date={wedding.event_date}/><div className="invite-paper rounded-2xl p-8 max-w-xl mx-auto mt-12"><MapPin className="mx-auto text-gold mb-3"/><h3 className="font-display text-2xl text-wine">{wedding.venue_name}</h3><p className="text-stone-500 mt-2">{wedding.venue_address}</p>{wedding.maps_url&&<a className="inline-block mt-5 text-wine underline" href={wedding.maps_url} target="_blank" rel="noreferrer">View directions</a>}</div></section>
    <section className="py-16 bg-[#f2e6d9] text-center"><h2 className="font-display text-3xl text-wine mb-8">A little music</h2><MusicPlayer src={wedding.music_url}/></section>
    <section className="py-24 px-5"><RSVPForm weddingId={wedding.id} guestId={guest?.id} maxGuests={guest?.household_size ?? 2}/></section>
    <footer className="py-12 text-center bg-wine text-cream"><p className="font-display text-3xl">With love, {wedding.groom_name} & {wedding.bride_name}</p><p className="text-xs tracking-widest uppercase mt-4 opacity-70">Thank you for celebrating with us</p></footer>
  </main>;
}
