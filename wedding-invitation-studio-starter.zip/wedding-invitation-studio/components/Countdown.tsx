"use client";
import { useEffect, useState } from "react";
export default function Countdown({ date }: { date: string }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const id = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(id); }, []);
  const distance = Math.max(0, new Date(date).getTime() - now);
  const values = [
    ["Days", Math.floor(distance / 86400000)],
    ["Hours", Math.floor(distance / 3600000) % 24],
    ["Minutes", Math.floor(distance / 60000) % 60],
    ["Seconds", Math.floor(distance / 1000) % 60]
  ] as const;
  return <div className="grid grid-cols-4 gap-2 max-w-lg mx-auto">{values.map(([label,value]) =>
    <div key={label} className="invite-paper rounded-xl py-4 px-2"><div className="font-display text-3xl text-wine tabular-nums">{String(value).padStart(2,"0")}</div><div className="text-[10px] uppercase tracking-widest text-stone-500">{label}</div></div>
  )}</div>;
}
