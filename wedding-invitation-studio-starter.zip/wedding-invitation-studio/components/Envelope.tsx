"use client";
import { useState } from "react";
export default function Envelope({ onOpen, guestName }: { onOpen:()=>void; guestName?:string }) {
  const [opened,setOpened] = useState(false);
  function open() { if (opened) return; setOpened(true); window.setTimeout(onOpen, 1150); }
  return <section className="min-h-screen flex flex-col items-center justify-center px-5 text-center">
    <p className="uppercase tracking-[.32em] text-gold text-xs mb-5">Together with their families</p>
    <h1 className="font-display text-4xl text-wine mb-3">You are cordially invited</h1>
    <p className="text-stone-500 mb-14">{guestName ? `Dear ${guestName},` : "A celebration of love and togetherness"}</p>
    <div className="envelope-scene">
      <button onClick={open} className={`envelope ${opened ? "open" : ""}`} aria-label="Open wedding invitation">
        <span className="envelope-back"/>
        <span className="envelope-letter"><span className="font-display text-wine text-xl">With love ♡</span></span>
        <span className="envelope-flap"/>
        <span className="envelope-front"/>
        <span className="ribbon"/>
      </button>
    </div>
    <p className="mt-14 text-xs tracking-[.25em] uppercase text-wine">{opened ? "Opening your invitation…" : "Tap the envelope to open"}</p>
    <p className="mt-2 text-gold text-lg">❧</p>
  </section>;
}
