"use client";
import { useEffect, useRef, useState } from "react";
import { MapPin, Heart, Flower2 } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);
import Envelope from "@/components/Envelope";
import Countdown from "@/components/Countdown";
import MusicPlayer from "@/components/MusicPlayer";
import RSVPForm from "@/components/RSVPForm";

const demo = {
  id:"demo-wedding-id", groom:"Kasun", bride:"Nethmi",
  date:"2027-02-14T10:00:00+05:30", dateLabel:"14 February 2027",
  time:"10.00 AM", venue:"A beautiful celebration venue", address:"Colombo, Sri Lanka"
};
export default function DemoInvitation() {
  const [opened,setOpened] = useState(false);
  const story = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!opened || !story.current) return;
    const ctx = gsap.context(() => {
      gsap.from(".reveal",{y:45,opacity:0,duration:1,stagger:.18,ease:"power3.out",scrollTrigger:undefined});
      gsap.from(".story-car",{x:-180,opacity:0,duration:1.5,scrollTrigger:{trigger:".story-scene",start:"top 75%",end:"bottom 35%",scrub:1}});
    },story);
    return () => ctx.revert();
  },[opened]);
  if (!opened) return <main><Envelope onOpen={()=>setOpened(true)} guestName="Our dear guest"/></main>;
  return <main ref={story} className="overflow-hidden">
    <header className="min-h-[90vh] flex flex-col justify-center items-center text-center px-5 story-scene">
      <p className="uppercase tracking-[.35em] text-gold text-xs mb-6 reveal">A celebration of love</p>
      <p className="font-display text-2xl text-wine reveal">The Wedding of</p>
      <h1 className="font-display text-6xl md:text-8xl text-wine my-5 reveal">{demo.groom}<span className="text-gold italic"> & </span>{demo.bride}</h1>
      <div className="gold-rule w-40 my-5 reveal"/>
      <p className="tracking-[.25em] uppercase text-sm reveal">{demo.dateLabel}</p>
      <p className="text-gold text-3xl mt-8">❧</p>
      <p className="text-xs uppercase tracking-widest text-stone-500 mt-10">Scroll to discover</p>
    </header>
    <section className="py-24 px-5 text-center max-w-3xl mx-auto">
      <Flower2 className="mx-auto text-gold mb-6" size={30}/>
      <p className="font-display text-3xl text-wine leading-relaxed">With the blessings of our families, we invite you to join us as we begin our forever.</p>
      <p className="mt-6 text-stone-500">Your presence will make our day even more special.</p>
    </section>
    <section className="story-scene min-h-[70vh] py-24 px-5 flex flex-col justify-center items-center text-center">
      <p className="uppercase tracking-[.3em] text-xs text-gold mb-6">Two hearts, one journey</p>
      <div className="text-7xl story-car mb-8" aria-label="Decorative wedding car">🚙</div>
      <h2 className="font-display text-4xl text-wine">A beautiful journey begins</h2>
      <p className="mt-4 max-w-lg text-stone-600">A little story, a lifetime of memories, and a day we cannot wait to share with you.</p>
    </section>
    <section className="py-24 px-5 text-center">
      <Heart className="mx-auto text-wine mb-5" size={28}/>
      <h2 className="font-display text-4xl text-wine mb-3">The Wedding Celebration</h2>
      <p className="text-stone-500 mb-10">{demo.dateLabel} · {demo.time}</p>
      <Countdown date={demo.date}/>
      <div className="invite-paper rounded-2xl p-8 max-w-xl mx-auto mt-12">
        <MapPin className="mx-auto text-gold mb-3"/>
        <h3 className="font-display text-2xl text-wine">{demo.venue}</h3>
        <p className="text-stone-500 mt-2">{demo.address}</p>
        <p className="text-xs text-stone-400 mt-4">Replace this demo venue with the actual wedding location.</p>
      </div>
    </section>
    <section className="py-16 px-5 text-center bg-[#f2e6d9]">
      <h2 className="font-display text-3xl text-wine mb-8">A little music for the moment</h2>
      <MusicPlayer/>
    </section>
    <section className="py-24 px-5">
      <RSVPForm weddingId={demo.id}/>
    </section>
    <footer className="py-12 text-center bg-wine text-cream">
      <p className="font-display text-3xl">With love, {demo.groom} & {demo.bride}</p>
      <p className="text-xs tracking-widest uppercase mt-4 opacity-70">We look forward to celebrating with you</p>
    </footer>
  </main>;
}
