import { notFound } from "next/navigation";
import InvitationBySlug from "@/components/InvitationBySlug";
import { getSupabase } from "@/lib/supabase";
export default async function WeddingPage({ params, searchParams }: { params:Promise<{slug:string}>; searchParams:Promise<{g?:string}> }) {
  const {slug}=await params; const {g}=await searchParams;
  let db; try { db=getSupabase(); } catch { notFound(); }
  const {data:wedding}=await db.from("weddings").select("*").eq("slug",slug).single();
  if(!wedding) notFound();
  let guest=null;
  if(g) { const {data}=await db.from("guests").select("id,full_name,household_size").eq("wedding_id",wedding.id).eq("token",g).single(); guest=data; }
  return <InvitationBySlug wedding={wedding} guest={guest}/>;
}
