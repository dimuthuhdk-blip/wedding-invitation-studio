"use client";
import { useEffect, useState } from "react";
import { getSupabase } from "@/lib/supabase";
type WeddingRow = { id:string; slug:string; groom_name:string; bride_name:string; event_date:string };
type RSVPRow = { id:string; guest_name:string; response:string; guest_count:number; created_at:string };
export default function AdminPage() {
  const [email,setEmail] = useState(""); const [password,setPassword] = useState("");
  const [user,setUser] = useState<string|null>(null); const [weddings,setWeddings] = useState<WeddingRow[]>([]);
  const [rsvps,setRsvps] = useState<RSVPRow[]>([]); const [selected,setSelected] = useState("");
  const [message,setMessage] = useState("");
  async function load() {
    try {
      const db=getSupabase(); const {data:auth}=await db.auth.getUser();
      setUser(auth.user?.email ?? null);
      if (!auth.user) return;
      const {data,error}=await db.from("weddings").select("id,slug,groom_name,bride_name,event_date").order("created_at",{ascending:false});
      if(error) throw error; setWeddings(data ?? []);
    } catch(e) { setMessage(e instanceof Error?e.message:"Could not load dashboard."); }
  }
  useEffect(()=>{ void load(); },[]);
  async function login(e:React.FormEvent) {
    e.preventDefault(); setMessage("");
    try { const {error}=await getSupabase().auth.signInWithPassword({email,password}); if(error) throw error; await load(); }
    catch(e) { setMessage(e instanceof Error?e.message:"Login failed."); }
  }
  async function showRsvps(id:string) {
    setSelected(id);
    const {data,error}=await getSupabase().from("rsvps").select("id,guest_name,response,guest_count,created_at").eq("wedding_id",id).order("created_at",{ascending:false});
    if(error) setMessage(error.message); else setRsvps(data ?? []);
  }
  async function logout() { await getSupabase().auth.signOut(); setUser(null); setWeddings([]); }
  if(!user) return <main className="min-h-screen grid place-items-center p-5"><form onSubmit={login} className="invite-paper rounded-2xl p-8 w-full max-w-md space-y-4"><p className="uppercase text-xs tracking-widest text-gold text-center">Wedding Invitation Studio</p><h1 className="font-display text-3xl text-wine text-center">Admin login</h1><input required type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} className="w-full border rounded-lg p-3"/><input required type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full border rounded-lg p-3"/><button className="w-full bg-wine text-white rounded-full p-3">Sign in</button>{message&&<p className="text-sm text-red-700">{message}</p>}<p className="text-xs text-stone-500">Create your admin user in Supabase Authentication first.</p></form></main>;
  return <main className="min-h-screen p-5 md:p-10 max-w-6xl mx-auto"><header className="flex justify-between items-center gap-4 mb-10"><div><p className="text-xs tracking-widest uppercase text-gold">Wedding Invitation Studio</p><h1 className="font-display text-4xl text-wine">Dashboard</h1><p className="text-sm text-stone-500">{user}</p></div><button onClick={logout} className="border border-gold rounded-full px-5 py-2 text-wine">Sign out</button></header>
    <section className="invite-paper rounded-2xl p-6 mb-8"><h2 className="font-display text-2xl text-wine mb-2">Your weddings</h2><p className="text-sm text-stone-500 mb-4">Create and edit wedding records in the Supabase Table Editor for this starter version.</p>{weddings.length===0?<p className="text-sm">No weddings yet. Add a record to the <code>weddings</code> table.</p>:<div className="space-y-3">{weddings.map(w=><div key={w.id} className="flex flex-wrap justify-between items-center gap-3 border-b border-stone-200 pb-3"><div><strong>{w.groom_name} & {w.bride_name}</strong><p className="text-xs text-stone-500">{w.event_date} · /{w.slug}</p></div><button onClick={()=>showRsvps(w.id)} className="text-sm rounded-full bg-wine text-white px-4 py-2">View RSVPs</button></div>)}</div>}</section>
    {selected&&<section className="invite-paper rounded-2xl p-6"><h2 className="font-display text-2xl text-wine mb-4">Guest responses</h2>{rsvps.length===0?<p className="text-sm text-stone-500">No responses yet.</p>:<div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left border-b"><th className="p-2">Guest</th><th className="p-2">Response</th><th className="p-2">Guests</th><th className="p-2">Received</th></tr></thead><tbody>{rsvps.map(r=><tr key={r.id} className="border-b"><td className="p-2">{r.guest_name}</td><td className="p-2">{r.response}</td><td className="p-2">{r.guest_count}</td><td className="p-2">{new Date(r.created_at).toLocaleString()}</td></tr>)}</tbody></table></div>}</section>}
    {message&&<p className="mt-4 text-sm text-red-700">{message}</p>}</main>;
}
