import Link from "next/link";
export default function Home() {
  return <main className="min-h-screen grid place-items-center p-6 text-center">
    <div className="max-w-xl">
      <p className="uppercase tracking-[.35em] text-gold text-xs mb-4">Wedding Invitation Studio</p>
      <h1 className="font-display text-5xl text-wine mb-4">A beautiful beginning.</h1>
      <p className="text-stone-600 mb-8">Your interactive Sri Lankan wedding invitation platform is ready to configure.</p>
      <div className="flex gap-3 justify-center flex-wrap">
        <Link className="rounded-full bg-wine text-white px-6 py-3" href="/demo">Preview invitation</Link>
        <Link className="rounded-full border border-gold text-wine px-6 py-3" href="/admin">Admin dashboard</Link>
      </div>
      <p className="text-xs text-stone-500 mt-8">Demo: /demo · Admin: /admin</p>
    </div>
  </main>;
}
